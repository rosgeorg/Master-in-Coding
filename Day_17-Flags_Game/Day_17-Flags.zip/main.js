(function(){
    "use strict"

    var banderas = document.querySelector('.flags');
    

    console.log(datos);
    //[{...}{...}{...}] -----> Arreglo de objetos
    console.log(datos[144]);
    //1.- paso escoger tres paises de manera aleatoria
    //console.log(Math.floor(Math.random()*250)) // 0 - 249
    //ceil ---> redondea hacia arriba
    //floor ---> redondea hacia abajo

    function obtenerPais(){
        var random = Math.floor(Math.random() * 250)
        console.log("Num Pais: ", random);
        return datos[random]
    }

    var paises = [];

    for(var i = 0; i<3; i++){
        var pais = obtenerPais();
        paises.push(pais)
    }

    console.log(paises);

})()